#include <iostream>
#include "menu.hpp"

using namespace std;

int main (){
    
    cout << "  i. Novo Jogo" << endl;
    cout << " ii. Continuar Jogo" << endl;
    cout << "iii. Opções" << endl;
    cout << " iv. Ajuda" << endl;
    cout << "  v. Créditos" << endl;

    return 0;
}
