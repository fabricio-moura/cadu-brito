#include <iostream>
#include "media.hpp"

int media (int x, int y, int z){
    int med = (x+y+z)/3;

    return med;
}