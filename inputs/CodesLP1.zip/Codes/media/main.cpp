#include <iostream>
#include "media.hpp"

using namespace std;

int main (){
    int x, y, z;
    
    cout << "Digite a pontuacao do primeiro jogador" << endl;
    cin >> x;
    cout << "Digite a pontuacao do segundo jogador" << endl;
    cin >> y;
    cout << "Digite a pontuacao do terceiro jogador" << endl;
    cin >> z;
    
    int result = media(x,y,z);
    cout << "Media: " << result << endl;

    return 0;
}
