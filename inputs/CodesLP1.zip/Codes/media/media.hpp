#ifndef MEDIA_HPP
#define MEDIA_HPP

int media (int x, int y, int z);

#endif